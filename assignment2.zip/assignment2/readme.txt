Program 2: Client using customized protocol on top of UDP protocol for requesting identification from server for access permission to the cellular network.

Follow the below steps for Server Program Compilation: 

	1. Enter the following command to compile server program       		     	- 		gcc -o server2 server2.c 
	2. Enter the following command to start the server                   		-		./server2

Follow the below steps for the Client Program Compilation:

	1. Enter the following command to compile client program         		     - 		gcc -o client2 client2.c
	2. Enter the following command to start the client and start sending packet  - 		./client2